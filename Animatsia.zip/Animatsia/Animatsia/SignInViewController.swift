//
//  SignInViewController.swift
//  Animatsia
//
//  Created by Student on 02.12.2021.
//

import UIKit

class SignInViewController: UIViewController {

        
        @IBOutlet weak var inputLogin: UITextField!
        @IBOutlet weak var inputPassword: UITextField!
        @IBOutlet weak var appNameLable: UILabel!
        @IBOutlet weak var logotype: UIImageView!

override func viewWillAppear(_ animated: Bool){
    
    self.inputLogin.center.x += self.view.bounds.width
    self.inputPassword.center.x -= self.view.bounds.width
    self.appNameLable.center.y += self.view.bounds.height
    self.logotype.center.y += self.view.bounds.height
}


override func viewDidAppear(_ animated: Bool ){
    UIView.animate(withDuration: 1.0){
        self.inputLogin.center.x += self.view.bounds.width
        self.inputPassword.center.x -= self.view.bounds.width
        self.appNameLable.center.y += self.view.bounds.height
        self.logotype.center.y += self.view.bounds.height
        
        
    }

}
}
