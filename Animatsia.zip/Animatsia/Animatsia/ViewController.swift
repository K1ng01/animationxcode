//
//  ViewController.swift
//  Animatsia
//
//  Created by Student on 02.12.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

